import os

class FileCreator:
    _dc_bot_folder = None
    _persons_folder = None
    _save_for_bots_folder = None
    _rec_images_folder = None

    @classmethod
    def create_folders(cls):
        if cls._dc_bot_folder is None:
            # Kullanıcı belgeler dosya yolunu al
            mainFolder = os.path.expanduser("~")
            dc_bot_folder = os.path.join(mainFolder, "DCBOT")
            print(dc_bot_folder)

            # DCBOT klasörünü oluştur veya zaten varsa geç
            if not os.path.exists(dc_bot_folder):
                os.makedirs(dc_bot_folder)
                print("DCBOT klasörü oluşturuldu:", dc_bot_folder)
            else:
                print("DCBOT klasörü zaten var:", dc_bot_folder)

            # DCBOT klasörü altında klasörlerin yollarını oluştur
            persons_folder = os.path.join(dc_bot_folder, "Persons")
            save_for_bots_folder = os.path.join(dc_bot_folder, "SaveForBots")
            rec_images_folder = os.path.join(dc_bot_folder, "RecImages")

            # Klasörleri kontrol et ve eksik olanları oluştur
            created_folders = []

            if not os.path.exists(persons_folder):
                os.makedirs(persons_folder)
                created_folders.append("Persons")

            if not os.path.exists(save_for_bots_folder):
                os.makedirs(save_for_bots_folder)
                created_folders.append("SaveForBots")

            if not os.path.exists(rec_images_folder):
                os.makedirs(rec_images_folder)
                created_folders.append("RecImages")

            if created_folders:
                print("Aşağıdaki klasör(ler) DCBOT klasörü içinde oluşturuldu:")
                for folder in created_folders:
                    print(folder)
            else:
                print("Mevcut klasörler zaten var, yeni klasör oluşturulmadı.")

            # Oluşturulan dosya yollarına erişim örneği
            cls._dc_bot_folder = dc_bot_folder
            cls._persons_folder = persons_folder
            cls._save_for_bots_folder = save_for_bots_folder
            cls._rec_images_folder = rec_images_folder

        return cls._dc_bot_folder, cls._persons_folder, cls._save_for_bots_folder, cls._rec_images_folder

# Klasörleri oluştur
dc_bot_folder, persons_folder, save_for_bots_folder, rec_images_folder = FileCreator.create_folders()

# Şimdi bu klasörleri kullanabilirsiniz
print("DC Bot Klasör:", dc_bot_folder)
print("Kişiler Klasörü:", persons_folder)
print("Botlar için Kaydet Klasörü:", save_for_bots_folder)
print("Tanıma için Klasör:", rec_images_folder)
