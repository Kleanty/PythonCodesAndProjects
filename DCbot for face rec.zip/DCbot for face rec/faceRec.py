import FileCreator
import face_recognition
import os

async def check_faces_in_photo(photo_path):
    # Tanımlı yüzleri içeren klasör
    folder_path = FileCreator.persons_folder

    known_faces = []
    matched_face_name = None

    # Klasördeki her bir görüntüyü işleyin
    for filename in os.listdir(folder_path):
        # Dosya yolunu oluştur
        image_path = os.path.join(folder_path, filename)

        # Görüntüyü yükle
        known_face = face_recognition.load_image_file(image_path)

        # Yüzleri kodla
        face_encodings = face_recognition.face_encodings(known_face)

        # Yüz bulunamazsa uyarı ver
        if len(face_encodings) == 0:
            print(f"{filename} dosyasında yüz bulunamadı.")
        else:
            # Birden fazla yüz varsa her bir yüzü listeye ekle
            for face_encoding in face_encodings:
                known_faces.append((filename, face_encoding))  # Filename ile face_encoding çiftini tuple olarak ekleyin

    # Tanımlı yüzlerin sayısını ve listesini görüntüle
    print("Tanımlı yüzlerin sayısı:", len(known_faces))
    print("Tanımlı yüzler:")
    print(known_faces)

    # Fotoğrafı yükle
    photo_image = face_recognition.load_image_file(photo_path)

    # Fotoğraftaki yüzleri kodla
    face_locations = face_recognition.face_locations(photo_image)
    face_encodings = face_recognition.face_encodings(photo_image, face_locations)

    # Yüz tanıma için her yüzü kontrol et
    for face_encoding in face_encodings:
        # Bu yüzün herhangi bir tanıdık yüzle eşleşip eşleşmediğini kontrol et
        for filename, known_face_encoding in known_faces:
            match = face_recognition.compare_faces([known_face_encoding], face_encoding)
            print(filename)
            if match[0]:
                print(f"Yüz, {filename} dosyasındaki bir kişiye ait.")
                matched_face_name = filename
                return matched_face_name

    print("Yüz tanınan kişi bulunamadı.")
    return None
