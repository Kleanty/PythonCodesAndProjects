import os


def count_files_in_directory(directory):
    # Verilen dizindeki dosyaların listesini al
    file_list = os.listdir(directory)

    # Dosya listesindeki her bir öğe için dosya mı klasör mü olduğunu kontrol et
    file_count = 0
    for item in file_list:
        # Dosya veya klasör mü kontrol et
        item_path = os.path.join(directory, item)
        if os.path.isfile(item_path):  # Eğer dosyaysa
            file_count += 1

    return file_count

def get_file_names_in_directory(directory):
    # Verilen dizindeki dosyaların listesini al
    file_list = os.listdir(directory)

    # Dosya isimlerini bir listeye ekleyin
    file_names = []
    for item in file_list:
        # Dosya ismini listeye ekleyin
        item_path = os.path.join(directory, item)
        if os.path.isfile(item_path):  # Eğer dosyaysa
            file_names.append(item)

    return file_names
