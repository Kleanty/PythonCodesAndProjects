import discord
from discord.ext import commands
import os
import faceRec
import FileCreator


# Botunuzu ayarlayın
prefix = "!"  # Botunuzun komutları tanıması için kullanılacak ön ek
# Botu başlatın
bot = commands.Bot(command_prefix=prefix,intents=discord.Intents.all())



@bot.event
async def on_ready():
    print(f"{bot.user.name} is ready!")

@bot.event
async def on_message(message):
    if message.channel.id == 504301285038751746 and message.attachments:
        for attachment in message.attachments:
            await attachment.save(os.path.join(FileCreator.rec_images_folder, attachment.filename))
        await message.channel.send("Bilgilendirme: Dosya Kaydedildi")
        # check_faces_in_photo fonksiyonu artık doğru bir şekilde await ile kullanılabilir
        photo_path = os.listdir(FileCreator.rec_images_folder)
        photo_Path = os.path.join(FileCreator.rec_images_folder, photo_path[-1])
        print(photo_Path)
        result = await faceRec.check_faces_in_photo(photo_Path)
        if result:
            await message.channel.send("Yüz tanınan bir kişiye ait.")
        else:
            await message.channel.send("Yüz tanınan kişi bulunamadı.")



# "ping" komutu tanımlama çallısıyormu deneme
@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

# Botu başlatma
bot.run("your token here ")