import serial
import cv2
import time
import face_recognition

# Tanınan yüzler ve kodlamalarını saklayacağımız liste
image = face_recognition.load_image_file("images/ahmet.jpg")  # Örnek bir yüz görüntüsü yüklendi
print(image)
# Initialize lists to store known encodings and names
known_encodings = []
known_names = []

# Append Ahmet's encoding and name to the lists
ahmet_encoding = face_recognition.face_encodings(image)[0]
known_encodings.append(ahmet_encoding)
known_names.append("Ahmet Taner")

# Arduino'ya bağlan
arduino = serial.Serial('COM3', 9600)
time.sleep(2)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
yuzCas = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
font = cv2.FONT_HERSHEY_COMPLEX

arduino_durum = False

while True:
    ret, frame = cap.read()
    frame = cv2.flip(frame, 1)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = yuzCas.detectMultiScale(gray, 1.3, 1)

    for (x, y, w, h) in faces:
        face_encoding = face_recognition.face_encodings(frame, [(y, x + w, y + h, x)])[0]
        matches = face_recognition.compare_faces(known_encodings, face_encoding)
        name = "Unknown"

        if True in matches:
            match_index = matches.index(True)
            name = known_names[match_index]

        cv2.putText(frame, name, (x, y - 10), font, 0.6, (0, 255, 0), 2)

    if len(faces) > 0:
        if not arduino_durum:
            arduino.write(b'1')
            arduino_durum = True
        cv2.putText(frame, "Yuz Tespit Edildi", (50, 50), font, 1, (255, 0, 0), 2, cv2.LINE_AA)
    else:
        if arduino_durum:
            arduino.write(b'0')
            arduino_durum = False
        cv2.putText(frame, "Yuz Tespit Edilmedi", (50, 50), font, 1, (255, 0, 0), 2, cv2.LINE_AA)

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 1)
    cv2.imshow("window", frame)

    if cv2.waitKey(30) & 0xFF == ord('q'):
        break

arduino.close()
cap.release()
cv2.destroyAllWindows()
