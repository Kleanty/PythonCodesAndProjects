import serial
import cv2
import time

arduino = serial.Serial('COM3', 9600)
time.sleep(2)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
yuzCas = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
font = cv2.FONT_HERSHEY_COMPLEX

arduino_durum = False  # Arduino'nun durumunu saklamak için bir değişken

while True:
    ret, frame = cap.read()
    frame = cv2.flip(frame, 1)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = yuzCas.detectMultiScale(gray, 1.3, 3)

    if len(faces) > 0:  # Yüzler tespit edildiyse
        if not arduino_durum:  # Eğer Arduino'nun durumu değiştiyse
            arduino.write(b'1')  # Arduino'ya 1 gönder
            arduino_durum = True  # Arduino'nun durumunu güncelle
        cv2.putText(frame, "Yuz Tespit Edildi", (50, 50), font, 1, (255, 0, 0), 2, cv2.LINE_AA)
    else:  # Yüzler tespit edilmediyse
        if arduino_durum:  # Eğer Arduino'nun durumu değiştiyse
            arduino.write(b'0')  # Arduino'ya 0 gönder
            arduino_durum = False  # Arduino'nun durumunu güncelle
        cv2.putText(frame, "Yuz Tespit Edilmedi", (50, 50), font, 1, (255, 0, 0), 2, cv2.LINE_AA)

    for x, y, w, h in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 1)
    cv2.imshow("window", frame)

    if cv2.waitKey(30) & 0xFF == ord('q'):
        break

arduino.close()
cap.release()
cv2.destroyAllWindows()
