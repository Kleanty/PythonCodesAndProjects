from PIL import Image
from pyzbar.pyzbar import decode


def read_qr_code(image_path: str) -> str:
    # Resmi aç
    img = Image.open(image_path)

    # QR kodlarını çöz
    decoded_objects = decode(img)

    # İlk QR kodunun verisini al
    if decoded_objects:
        return decoded_objects[0].data.decode('utf-8')
    else:
        return "QR kodu bulunamadı veya okunamadı."
