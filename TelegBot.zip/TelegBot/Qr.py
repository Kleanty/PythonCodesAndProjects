import qrcode
import os


def create_qr_code(data, file_path):
    """Create a QR code and save it to the specified file path."""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)

    img = qr.make_image(fill='black', back_color='white')

    # Dosya yolunun dizin kısmını al
    dir_name = os.path.dirname(file_path)

    # Dizinin var olup olmadığını kontrol et ve yoksa oluştur
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)

    img.save(file_path)
