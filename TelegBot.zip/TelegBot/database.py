# database.py

import sqlite3

DATABASE_NAME = 'DataBase.db'

def initialize_db():
    """Veritabanını ve gerekli tabloları oluşturur."""
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    # `customers` tablosunu oluşturur
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fullName TEXT,
        TC TEXT UNIQUE,
        plaka TEXT,
        sonIslemler TEXT,
        password TEXT UNIQUE
    )
    ''')

    conn.commit()
    conn.close()

def add_customer(full_name, tc, plaka, son_islemler, password):
    """Yeni müşteri ekler."""
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    INSERT INTO customers (fullName, TC, plaka, sonIslemler, password)
    VALUES (?, ?, ?, ?, ?)
    ''', (full_name, tc, plaka, son_islemler, password))

    conn.commit()
    conn.close()

def get_customer_by_tc(tc):
    """TC numarasına göre müşteri bilgilerini getirir."""
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    SELECT * FROM customers WHERE TC = ?
    ''', (tc,))

    customer = cursor.fetchone()
    conn.close()

    return customer

def update_customer_last_transaction(tc, last_transaction):
    """Müşterinin son işlemlerini günceller."""
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    UPDATE customers
    SET sonIslemler = ?
    WHERE TC = ?
    ''', (last_transaction, tc))

    conn.commit()
    conn.close()

def get_all_passwords():
    """Tüm şifreleri getirir."""
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    cursor.execute('SELECT password FROM customers')
    passwords = [row[0] for row in cursor.fetchall()]

    conn.close()

    return passwords

def get_customer_by_qr_info(qr_info):
    """QR bilgisine göre müşteri bilgilerini getirir."""
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    cursor.execute('''
    SELECT * FROM customers WHERE password = ?
    ''', (qr_info,))

    customer = cursor.fetchone()
    conn.close()

    return customer
