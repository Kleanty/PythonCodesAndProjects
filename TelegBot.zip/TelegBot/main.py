import nest_asyncio
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
import Qr
import string
import random
import database
import os
from datetime import datetime
import QrReader

# nest_asyncio ile mevcut olay döngüsünü yama yap
nest_asyncio.apply()

NEW_CUSTOMER = 1
OLD_CUSTOMER = 2
QR_QUERY = 3
CUSTOMER_DATA = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("Yeni Müşteri", callback_data='1')],
        [InlineKeyboardButton("Eski Müşteri", callback_data='2')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Bir seçenek belirleyin:', reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    choice = query.data
    chat_id = query.message.chat_id

    if choice == '1':
        CUSTOMER_DATA[chat_id] = {'stage': NEW_CUSTOMER, 'data': {}}
        await query.edit_message_text(text="Adınızı ve Soyadınızı girin:")
    elif choice == '2':
        CUSTOMER_DATA[chat_id] = {'stage': QR_QUERY}  # QR kodu sorgulama aşamasına geç
        await query.edit_message_text(text="Lütfen QR kodu fotoğrafını gönderin:")
    else:
        await query.edit_message_text(text="Bilinmeyen bir seçenek seçildi.")

async def handle_new_customer(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int) -> None:
    customer_stage = CUSTOMER_DATA[chat_id]['data']

    if 'fullName' not in customer_stage:
        customer_stage['fullName'] = update.message.text
        await update.message.reply_text("TC numaranızı girin:")
    elif 'TC' not in customer_stage:
        customer_stage['TC'] = update.message.text
        await update.message.reply_text("Plakanızı girin:")
    elif 'plaka' not in customer_stage:
        customer_stage['plaka'] = update.message.text
        await update.message.reply_text("Araç üzerinde uygulanan son işlemleri girin:")
    elif 'sonIslemler' not in customer_stage:
        customer_stage['sonIslemler'] = update.message.text
        await process_new_customer(update, context, chat_id, customer_stage)

async def process_new_customer(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, customer_stage: dict) -> None:
    random_password = generate_unique_numeric_password(12)
    valid_file_name = random_password
    file_path = rf'C:\Users\Kroah\PycharmProjects\TelegBot\CreatedQrs\{valid_file_name}.png'
    Qr.create_qr_code(random_password, file_path)
    if os.path.exists(file_path):
        try:
            await context.bot.send_photo(chat_id=chat_id, photo=open(file_path, 'rb'))
            database.add_customer(
                customer_stage['fullName'],
                customer_stage['TC'],
                customer_stage['plaka'],
                customer_stage['sonIslemler'],
                random_password
            )
            await update.message.reply_text(f"Yeni Müşteri eklendi. QR kodu oluşturuldu. Şifre: {random_password}")
        except Exception as e:
            await update.message.reply_text(f"QR kodunu gönderirken bir hata oluştu: {e}")
    else:
        await update.message.reply_text("QR kodu oluşturulurken bir hata oluştu.")
        del CUSTOMER_DATA[chat_id]

async def handle_qr_query(update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int) -> None:
    if update.message.photo:
        photo_file = await update.message.photo[-1].get_file()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        photo_path = rf'C:\Users\Kroah\PycharmProjects\TelegBot\ReadedQrs\qr_code_image_{timestamp}.png'
        await photo_file.download_to_drive(photo_path)

        qr_info = QrReader.read_qr_code(photo_path)
        if qr_info:
            customer = database.get_customer_by_qr_info(qr_info)
            if customer:
                await update.message.reply_text(f"Müşteri Bilgileri:\nAd Soyad: {customer[1]}\nTC: {customer[2]}\nPlaka: {customer[3]}\nSon İşlemler: {customer[4]}\nŞifre: {customer[5]}")
            else:
                await update.message.reply_text("QR kodu ile ilişkilendirilmiş müşteri bulunamadı.")
        else:
            await update.message.reply_text("QR kodu okunamadı.")
        del CUSTOMER_DATA[chat_id]
    else:
        await update.message.reply_text("Lütfen bir fotoğraf gönderin.")

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = update.message.chat_id

    if chat_id not in CUSTOMER_DATA:
        await update.message.reply_text("Lütfen önce bir seçenek belirleyin (/start komutu ile).")
        return

    stage = CUSTOMER_DATA[chat_id].get('stage')

    if stage == NEW_CUSTOMER:
        await handle_new_customer(update, context, chat_id)
    elif stage == OLD_CUSTOMER:
        await handle_old_customer(update, context, chat_id)
    elif stage == QR_QUERY:
        await handle_qr_query(update, context, chat_id)
    elif 'TC' in CUSTOMER_DATA[chat_id]:
        TC = CUSTOMER_DATA[chat_id]['TC']
        database.update_customer_last_transaction(TC, update.message.text)
        await update.message.reply_text("Son işlemler güncellendi.")
        del CUSTOMER_DATA[chat_id]

def generate_unique_numeric_password(length: int) -> str:
    existing_passwords = database.get_all_passwords()
    while True:
        password = ''.join(random.choices(string.digits, k=length))
        if password not in existing_passwords:
            return password

async def main() -> None:
    database.initialize_db()  # Veritabanını başlat
    TOKEN = '***your token here**'
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    application.add_handler(MessageHandler(filters.PHOTO, message_handler))

    await application.run_polling()

if __name__ == '__main__':
    asyncio.run(main())
